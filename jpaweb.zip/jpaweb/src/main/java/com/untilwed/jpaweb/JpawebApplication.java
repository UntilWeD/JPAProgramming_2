package com.untilwed.jpaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpawebApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpawebApplication.class, args);
	}

}
